
function changeColor(button) {
    button.style.color = (button.style.color === 'red') ? '' : 'red';
  }
  

  